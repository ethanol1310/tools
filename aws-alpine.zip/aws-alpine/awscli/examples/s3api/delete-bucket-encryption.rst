**To delete the server-side encryption configuration of a bucket**

The following ``delete-bucket-encryption`` example deletes the server-side encryption configuration of the specified bucket. ::

    aws s3api delete-bucket-encryption \
        --bucket my-bucket

This command produces no output.
